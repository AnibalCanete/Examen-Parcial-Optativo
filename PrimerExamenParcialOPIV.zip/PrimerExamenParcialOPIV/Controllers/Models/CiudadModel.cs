﻿namespace PrimerExamenParcialOPIV.Controllers.Models
{
    public class CiudadModel
    {
        public string id { get; set; }
        public string ciudad { get; set; }
        public string estado { get; set; }
    }
}
