﻿namespace PrimerExamenParcialOPIV.Controllers.Models
{
    public class ClienteModel
    {
        public int id { get; set; }
        public int idCiudad { get; set; }
        public string nombres { get; set; }
        public string apellidos { get; set; }
        public int documento { get; set; }
        public int telefono { get; set; }
        public string email { get; set; }
        public string fechaNacimiento { get; set; }
        public string ciudad { get; set; }
        public string nacionalidad { get; set; }

    }
}
