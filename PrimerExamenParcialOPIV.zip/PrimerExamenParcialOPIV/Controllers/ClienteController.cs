﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace PrimerExamenParcialOPIV.Controllers
{
    public class ClienteController : Controller
    {
        [HttpPost("ConsultarCliente/{id}")]

        public ActionResult<ClienteModel> ConsultarCliente(int id)
        {
            var resultado = this.clienteService.consultarCliente(id);
            return Ok(resultado);
        }

        [HttpPost("InsertarCliente")]
        public ActionResult<string> insertarCliente(ClienteModel modelo)
        {
            var resultado = this.Clienteservice.insertarCliente(new infraestructure.Models.ClienteModel
            {
                id = modelo.id,
                idCiudad = modelo.idCiudad,
                nombres = modelo.nombres,
                apellidos = modelo.apellidos,
                documento = modelo.documento,
                telefono = modelo.telefono,
                email = modelo.email,
                fechaNacimiento = modelo.fechaNacimiento,
                ciudad = modelo.ciudad,
                nacionalidad = modelo.nacionalidad,
            });
            return Ok(resultado);
        }

        [HttpPost("modificarCliente/{id}")]

        public ActionResult<string> modificarCliente(ClienteModel modelo, int id) 
        {
            var resultado = this.clienteService.modificarCliente(new infraestructure.Models.ClienteModel
            {
                idCiudad = modelo.idCiudad,
                nombres = modelo.nombres,
                apellidos = modelo.apellidos,
                documento = modelo.documento,
                telefono = modelo.telefono,
                email = modelo.email,
                fechaNacimiento = modelo.fechaNacimiento,
                ciudad = modelo.ciudad,
                nacionalidad = modelo.nacionalidad,
            }, id);
            return Ok(resultado);
        }

        [HttpPost("eliminarCliente/{id}")]

        public ActionResult<string> eliminarCliente(int id)
        {
            var resultado = this.clienteService.eliminarCliente(id);
            return Ok(resultado);
        }
        // GET: ClienteController
        public ActionResult Index()
        {
            return View();
        }

        // GET: ClienteController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: ClienteController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ClienteController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ClienteController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: ClienteController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: ClienteController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: ClienteController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
